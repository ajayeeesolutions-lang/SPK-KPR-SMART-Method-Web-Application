<?php $__env->startSection('title', 'Edit Data Pengajuan KPR'); ?>
<?php $__env->startSection('page-title', 'Edit Data Pengajuan KPR'); ?>

<?php $__env->startSection('content'); ?>
<div class="card-custom p-4">
    <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom">
        <div>
            <h5 class="fw-bold text-dark mb-1">Edit Pengajuan <?php echo e($submission->no_pengajuan); ?></h5>
            <div class="text-muted small">Ubah nilai pengajuan atau atribut kriteria nasabah.</div>
        </div>
        <a href="<?php echo e(route('admin.applicants.show', ['applicant' => $submission->id])); ?>" class="btn btn-outline-secondary btn-sm rounded-pill"><i class="fa-solid fa-arrow-left me-1"></i> Batal</a>
    </div>

    <form action="<?php echo e(route('admin.applicants.update', ['applicant' => $submission->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row g-3">
            <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">Nama Nasabah</label>
                <input type="text" name="name" value="<?php echo e(old('name', $submission->user?->name)); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">Harga Rumah (Rp)</label>
                <input type="number" name="harga_rumah" value="<?php echo e(old('harga_rumah', $submission->harga_rumah)); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Uang Muka DP (Rp)</label>
                <input type="number" name="uang_muka_dp" value="<?php echo e(old('uang_muka_dp', $submission->uang_muka_dp)); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Plafon Pinjaman (Rp)</label>
                <input type="number" name="nilai_pinjaman" value="<?php echo e(old('nilai_pinjaman', $submission->nilai_pinjaman)); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Tenor (Tahun)</label>
                <input type="number" name="tenor_tahun" value="<?php echo e(old('tenor_tahun', $submission->tenor_tahun)); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">Penghasilan Bulanan (Rp) (C1)</label>
                <input type="number" name="penghasilan_bulanan" value="<?php echo e(old('penghasilan_bulanan', $submission->user?->profile?->penghasilan_bulanan ?? 0)); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">Lama Bekerja (Bulan) (C2)</label>
                <input type="number" name="lama_bekerja_bulan" value="<?php echo e(old('lama_bekerja_bulan', $submission->user?->profile?->lama_bekerja_bulan ?? 0)); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">Status Pekerjaan (C4)</label>
                <select name="status_pekerjaan" class="form-select" required>
                    <?php $__currentLoopData = ['PNS/BUMN', 'Pegawai Tetap Swasta', 'Wirausaha', 'Pegawai Kontrak', 'Lainnya']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($st); ?>" <?php echo e(($submission->user?->profile?->status_pekerjaan ?? '') === $st ? 'selected' : ''); ?>><?php echo e($st); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">Riwayat Kredit / SLIK (C5)</label>
                <select name="riwayat_kredit" class="form-select" required>
                    <?php $__currentLoopData = ['Lancar', 'Dalam Perhatian', 'Tidak Lancar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($rk); ?>" <?php echo e(($submission->user?->profile?->riwayat_kredit ?? '') === $rk ? 'selected' : ''); ?>><?php echo e($rk); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="mt-4 pt-3 border-top text-end">
            <button type="submit" class="btn btn-primary px-4 rounded-3 shadow"><i class="fa-solid fa-save me-1"></i> Simpan & Recalculate SMART</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT TEMPLATE JUAL\APLIKASI ASEP\resources\views/admin/applicants/edit.blade.php ENDPATH**/ ?>