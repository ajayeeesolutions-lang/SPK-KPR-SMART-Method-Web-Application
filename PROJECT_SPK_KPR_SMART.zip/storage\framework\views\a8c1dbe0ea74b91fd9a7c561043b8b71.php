<?php $__env->startSection('title', 'Kelola User & Role Access'); ?>
<?php $__env->startSection('page-title', 'Kelola User System (Admin, Manager, Nasabah)'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-3">
    <!-- User List -->
    <div class="col-12 col-lg-8">
        <div class="card-custom p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold text-dark mb-0">Daftar Pengguna Sistem</h5>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light small text-uppercase">
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>No. HP</th>
                            <th>Role Access</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><div class="fw-bold text-dark"><?php echo e($u->name); ?></div></td>
                                <td><?php echo e($u->email); ?></td>
                                <td><?php echo e($u->phone ?? '-'); ?></td>
                                <td>
                                    <?php if($u->role === 'admin'): ?>
                                        <span class="badge bg-primary text-uppercase">Admin</span>
                                    <?php elseif($u->role === 'manager'): ?>
                                        <span class="badge bg-success text-uppercase">Manager</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary text-uppercase">Nasabah</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <form action="<?php echo e(route('admin.users.destroy', $u->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus user ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-light border text-danger" <?php echo e($u->id === auth()->id() ? 'disabled' : ''); ?>><i class="fa-solid fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>

    <!-- Add User Form -->
    <div class="col-12 col-lg-4">
        <div class="card-custom p-4">
            <h6 class="fw-bold text-dark mb-3"><i class="fa-solid fa-user-plus text-primary me-2"></i> Tambah User Baru</h6>
            <form action="<?php echo e(route('admin.users.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nama Lengkap</label>
                    <input type="text" name="name" class="form-control" placeholder="Nama..." required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="email@bank.com" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nomor Handphone</label>
                    <input type="text" name="phone" class="form-control" placeholder="0812...">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Role Hak Akses</label>
                    <select name="role" class="form-select" required>
                        <option value="admin">Admin</option>
                        <option value="manager">Manager Analis</option>
                        <option value="nasabah">Calon Nasabah</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Minimal 8 karakter" required>
                </div>
                <button type="submit" class="btn btn-primary w-100 shadow-sm"><i class="fa-solid fa-save me-1"></i> Simpan User</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT TEMPLATE JUAL\APLIKASI ASEP\resources\views/admin/users/index.blade.php ENDPATH**/ ?>