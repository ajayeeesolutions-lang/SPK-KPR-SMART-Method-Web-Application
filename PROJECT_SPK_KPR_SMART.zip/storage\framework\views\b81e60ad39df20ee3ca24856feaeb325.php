<?php $__env->startSection('title', 'Manager Executive Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard Eksekutif Manager KPR'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom p-3 d-flex align-items-center flex-row gap-3">
            <div class="rounded-3 bg-warning bg-opacity-10 text-warning p-3 d-flex align-items-center justify-content-center" style="width: 54px; height: 54px;">
                <i class="fa-solid fa-clipboard-check fs-3"></i>
            </div>
            <div>
                <div class="text-muted small fw-semibold">Butuh Persetujuan</div>
                <h3 class="fw-bold mb-0 text-warning"><?php echo e($totalPendingApproval); ?></h3>
                <small class="text-muted">Siap Diteken</small>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom p-3 d-flex align-items-center flex-row gap-3">
            <div class="rounded-3 bg-success bg-opacity-10 text-success p-3 d-flex align-items-center justify-content-center" style="width: 54px; height: 54px;">
                <i class="fa-solid fa-circle-check fs-3"></i>
            </div>
            <div>
                <div class="text-muted small fw-semibold">Disetujui (Approved)</div>
                <h3 class="fw-bold mb-0 text-success"><?php echo e($totalDiterima); ?></h3>
                <small class="text-muted">Rekomendasi Diterima</small>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom p-3 d-flex align-items-center flex-row gap-3">
            <div class="rounded-3 bg-danger bg-opacity-10 text-danger p-3 d-flex align-items-center justify-content-center" style="width: 54px; height: 54px;">
                <i class="fa-solid fa-circle-xmark fs-3"></i>
            </div>
            <div>
                <div class="text-muted small fw-semibold">Ditolak (Rejected)</div>
                <h3 class="fw-bold mb-0 text-danger"><?php echo e($totalDitolak); ?></h3>
                <small class="text-muted">Rekomendasi Ditolak</small>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom p-3 d-flex align-items-center flex-row gap-3">
            <div class="rounded-3 bg-primary bg-opacity-10 text-primary p-3 d-flex align-items-center justify-content-center" style="width: 54px; height: 54px;">
                <i class="fa-solid fa-folder-open fs-3"></i>
            </div>
            <div>
                <div class="text-muted small fw-semibold">Total Pengajuan</div>
                <h3 class="fw-bold mb-0 text-primary"><?php echo e($totalPengajuan); ?></h3>
                <small class="text-muted">Seluruh Portofolio</small>
            </div>
        </div>
    </div>
</div>

<div class="card-custom p-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="fw-bold text-dark mb-0"><i class="fa-solid fa-list-check text-primary me-2"></i> Pengajuan Butuh Persetujuan Akhir Manager</h6>
        <a href="<?php echo e(route('manager.submissions.index')); ?>" class="btn btn-sm btn-outline-primary rounded-pill">Lihat Semua</a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light small">
                <tr>
                    <th>No. Pengajuan</th>
                    <th>Nama Nasabah</th>
                    <th>Plafon Pinjaman</th>
                    <th>Skor SMART</th>
                    <th>Hasil Rekomendasi Engine</th>
                    <th class="text-center">Aksi Manager</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recentSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><span class="fw-bold text-primary"><?php echo e($sub->no_pengajuan); ?></span></td>
                        <td>
                            <div class="fw-bold text-dark"><?php echo e($sub->user->name); ?></div>
                            <small class="text-muted"><?php echo e($sub->user->profile->pekerjaan ?? '-'); ?></small>
                        </td>
                        <td>Rp <?php echo e(number_format($sub->nilai_pinjaman, 0, ',', '.')); ?></td>
                        <td><span class="fw-bold fs-6 text-primary"><?php echo e(number_format($sub->final_smart_score ?? 0, 2)); ?></span></td>
                        <td>
                            <?php if($sub->status_keputusan === 'DITERIMA'): ?>
                                <span class="badge-success-custom">DITERIMA</span>
                            <?php else: ?>
                                <span class="badge-danger-custom">TIDAK DITERIMA</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <a href="<?php echo e(route('manager.submissions.show', $sub->id)); ?>" class="btn btn-sm btn-primary rounded-3 px-3 shadow-sm">
                                <i class="fa-solid fa-file-signature me-1"></i> Review & Decision
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">Tidak ada pengajuan yang menunggu approval.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT TEMPLATE JUAL\APLIKASI ASEP\resources\views/manager/dashboard.blade.php ENDPATH**/ ?>