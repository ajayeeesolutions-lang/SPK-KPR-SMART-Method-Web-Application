<?php $__env->startSection('title', 'Admin Enterprise Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard System & Summary Analyst'); ?>

<?php $__env->startSection('content'); ?>
<!-- Metric Cards Grid -->
<div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom p-3 d-flex align-items-center flex-row gap-3">
            <div class="rounded-3 bg-primary bg-opacity-10 text-primary p-3 d-flex align-items-center justify-content-center" style="width: 54px; height: 54px;">
                <i class="fa-solid fa-file-invoice fs-3"></i>
            </div>
            <div>
                <div class="text-muted small fw-semibold">Total Pengajuan</div>
                <h3 class="fw-bold mb-0 text-dark"><?php echo e($totalPengajuan); ?></h3>
                <small class="text-success fw-bold"><i class="fa-solid fa-arrow-trend-up"></i> +12% bln lalu</small>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom p-3 d-flex align-items-center flex-row gap-3">
            <div class="rounded-3 bg-success bg-opacity-10 text-success p-3 d-flex align-items-center justify-content-center" style="width: 54px; height: 54px;">
                <i class="fa-solid fa-circle-check fs-3"></i>
            </div>
            <div>
                <div class="text-muted small fw-semibold">Total Diterima</div>
                <h3 class="fw-bold mb-0 text-success"><?php echo e($totalDiterima); ?></h3>
                <small class="text-muted">Skor SMART ≥ 80</small>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom p-3 d-flex align-items-center flex-row gap-3">
            <div class="rounded-3 bg-danger bg-opacity-10 text-danger p-3 d-flex align-items-center justify-content-center" style="width: 54px; height: 54px;">
                <i class="fa-solid fa-circle-xmark fs-3"></i>
            </div>
            <div>
                <div class="text-muted small fw-semibold">Total Ditolak</div>
                <h3 class="fw-bold mb-0 text-danger"><?php echo e($totalDitolak); ?></h3>
                <small class="text-muted">Skor SMART < 80</small>
            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom p-3 d-flex align-items-center flex-row gap-3">
            <div class="rounded-3 bg-warning bg-opacity-10 text-warning p-3 d-flex align-items-center justify-content-center" style="width: 54px; height: 54px;">
                <i class="fa-solid fa-hourglass-half fs-3"></i>
            </div>
            <div>
                <div class="text-muted small fw-semibold">Menunggu Verifikasi</div>
                <h3 class="fw-bold mb-0 text-warning"><?php echo e($totalMenunggu); ?></h3>
                <small class="text-muted">Pending/Analyzed</small>
            </div>
        </div>
    </div>
</div>

<!-- Charts Row -->
<div class="row g-3 mb-4">
    <div class="col-12 col-lg-8">
        <div class="card-custom p-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="fw-bold text-dark mb-0"><i class="fa-solid fa-chart-line text-primary me-2"></i> Grafik Trend Pengajuan Bulanan</h6>
                <span class="badge bg-light text-secondary border">6 Bulan Terakhir</span>
            </div>
            <div style="height: 260px;">
                <canvas id="monthlyChart"></canvas>
            </div>
        </div>
    </div>

    <div class="col-12 col-lg-4">
        <div class="card-custom p-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="fw-bold text-dark mb-0"><i class="fa-solid fa-chart-pie text-cyan me-2"></i> Persentase Decision KPR</h6>
            </div>
            <div style="height: 200px;" class="d-flex justify-content-center align-items-center position-relative">
                <canvas id="decisionChart"></canvas>
            </div>
            <div class="d-flex justify-content-center gap-4 mt-3 pt-3 border-top small">
                <div><i class="fa-solid fa-circle text-success me-1"></i> Diterima (<?php echo e($totalDiterima); ?>)</div>
                <div><i class="fa-solid fa-circle text-danger me-1"></i> Ditolak (<?php echo e($totalDitolak); ?>)</div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions & Recent Submissions -->
<div class="row g-3">
    <div class="col-12 col-lg-4">
        <div class="card-custom p-4 h-100">
            <h6 class="fw-bold text-dark mb-3"><i class="fa-solid fa-bolt text-warning me-2"></i> Quick Actions Admin</h6>
            <div class="d-grid gap-2">
                <a href="<?php echo e(route('admin.applicants.create')); ?>" class="btn btn-primary rounded-3 text-start p-3 shadow-sm">
                    <i class="fa-solid fa-user-plus me-2"></i> <strong>Tambah Nasabah Baru</strong>
                    <div class="small opacity-75">Input data diri & nilai pengajuan KPR</div>
                </a>
                <a href="<?php echo e(route('admin.smart.engine')); ?>" class="btn btn-dark rounded-3 text-start p-3 shadow-sm">
                    <i class="fa-solid fa-microchip me-2 text-cyan"></i> <strong>Jalankan Mesin SMART</strong>
                    <div class="small opacity-75">Proses perhitungan otomatis & ranking</div>
                </a>
                <a href="<?php echo e(route('admin.criteria.index')); ?>" class="btn btn-light border rounded-3 text-start p-3">
                    <i class="fa-solid fa-sliders me-2 text-primary"></i> <strong>Kelola Kriteria & Bobot</strong>
                    <div class="small text-muted">Ubah bobot awal kriteria SMART</div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-12 col-lg-8">
        <div class="card-custom p-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="fw-bold text-dark mb-0"><i class="fa-solid fa-clock-rotate-left text-primary me-2"></i> Pengajuan KPR Terbaru</h6>
                <a href="<?php echo e(route('admin.applicants.index')); ?>" class="btn btn-sm btn-outline-primary rounded-pill">Lihat Semua</a>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small">
                        <tr>
                            <th>No. Registrasi</th>
                            <th>Nama Nasabah</th>
                            <th>Nilai Pinjaman</th>
                            <th>Skor SMART</th>
                            <th>Keputusan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><span class="fw-bold text-primary"><?php echo e($sub->no_pengajuan); ?></span></td>
                                <td>
                                    <div class="fw-semibold text-dark"><?php echo e($sub->user->name); ?></div>
                                    <small class="text-muted"><?php echo e($sub->user->profile->pekerjaan ?? '-'); ?></small>
                                </td>
                                <td>Rp <?php echo e(number_format($sub->nilai_pinjaman, 0, ',', '.')); ?></td>
                                <td>
                                    <?php if($sub->final_smart_score): ?>
                                        <span class="fw-bold fs-6"><?php echo e(number_format($sub->final_smart_score, 2)); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-muted border">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($sub->status_keputusan === 'DITERIMA'): ?>
                                        <span class="badge-success-custom"><i class="fa-solid fa-circle-check me-1"></i> DITERIMA</span>
                                    <?php elseif($sub->status_keputusan === 'TIDAK DITERIMA'): ?>
                                        <span class="badge-danger-custom"><i class="fa-solid fa-circle-xmark me-1"></i> TIDAK DITERIMA</span>
                                    <?php else: ?>
                                        <span class="badge-warning-custom"><i class="fa-solid fa-clock me-1"></i> Menunggu</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.applicants.show', $sub->id)); ?>" class="btn btn-sm btn-light border rounded-circle"><i class="fa-solid fa-eye text-secondary"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">Belum ada pengajuan KPR.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const ctxMonthly = document.getElementById('monthlyChart').getContext('2d');
    new Chart(ctxMonthly, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun'],
            datasets: [{
                label: 'Jumlah Pengajuan',
                data: [12, 19, 15, 25, 22, <?php echo e($totalPengajuan); ?>],
                borderColor: '#2563EB',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                fill: true,
                tension: 0.4,
                pointRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true } }
        }
    });

    const ctxDecision = document.getElementById('decisionChart').getContext('2d');
    new Chart(ctxDecision, {
        type: 'doughnut',
        data: {
            labels: ['Diterima', 'Ditolak'],
            datasets: [{
                data: [<?php echo e($totalDiterima); ?>, <?php echo e($totalDitolak); ?>],
                backgroundColor: ['#10B981', '#EF4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: { legend: { display: false } }
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT TEMPLATE JUAL\APLIKASI ASEP\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>