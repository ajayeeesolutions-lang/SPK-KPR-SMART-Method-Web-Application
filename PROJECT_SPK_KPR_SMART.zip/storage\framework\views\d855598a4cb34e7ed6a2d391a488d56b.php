<?php $__env->startSection('title', 'Master Kriteria & Bobot SMART'); ?>
<?php $__env->startSection('page-title', 'Kelola Kriteria & Bobot SMART'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-3">
    <!-- Criteria List Table -->
    <div class="col-12 col-lg-8">
        <div class="card-custom p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h5 class="fw-bold text-dark mb-1">Daftar Kriteria SMART</h5>
                    <div class="text-muted small">Total bobot kriteria saat ini: <strong class="<?php echo e($totalWeight == 100 ? 'text-success' : 'text-danger'); ?>"><?php echo e(number_format($totalWeight, 2)); ?>%</strong></div>
                </div>

                <?php if($totalWeight != 100): ?>
                    <div class="badge bg-danger p-2" title="Total bobot idealnya adalah 100%">
                        <i class="fa-solid fa-triangle-exclamation me-1"></i> Total Bobot ≠ 100%
                    </div>
                <?php else: ?>
                    <div class="badge bg-success p-2">
                        <i class="fa-solid fa-circle-check me-1"></i> Total Bobot 100% Valid
                    </div>
                <?php endif; ?>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light small text-uppercase">
                        <tr>
                            <th>Kode</th>
                            <th>Nama Kriteria</th>
                            <th>Tipe</th>
                            <th>Bobot Awal ($W$)</th>
                            <th>Status</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="badge bg-primary fs-6 fw-bold"><?php echo e($crit->code); ?></span></td>
                                <td><div class="fw-bold text-dark"><?php echo e($crit->name); ?></div></td>
                                <td>
                                    <?php if($crit->type === 'benefit'): ?>
                                        <span class="badge bg-success bg-opacity-10 text-success fw-bold text-uppercase">Benefit</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning bg-opacity-10 text-warning fw-bold text-uppercase">Cost</span>
                                    <?php endif; ?>
                                </td>
                                <td><span class="fw-bold fs-6"><?php echo e(number_format($crit->weight, 2)); ?>%</span></td>
                                <td>
                                    <?php if($crit->is_active): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Non-Aktif</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-light border text-warning" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($crit->id); ?>"><i class="fa-solid fa-pen"></i></button>
                                    <form action="<?php echo e(route('admin.criteria.destroy', $crit->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus kriteria ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-light border text-danger"><i class="fa-solid fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>

                            <!-- Edit Modal -->
                            <div class="modal fade" id="editModal<?php echo e($crit->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form action="<?php echo e(route('admin.criteria.update', $crit->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-header">
                                                <h5 class="modal-title fw-bold">Edit Kriteria <?php echo e($crit->code); ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Nama Kriteria</label>
                                                    <input type="text" name="name" value="<?php echo e($crit->name); ?>" class="form-control" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Tipe Kriteria</label>
                                                    <select name="type" class="form-select" required>
                                                        <option value="benefit" <?php echo e($crit->type === 'benefit' ? 'selected' : ''); ?>>Benefit (Semakin besar nilai, semakin baik)</option>
                                                        <option value="cost" <?php echo e($crit->type === 'cost' ? 'selected' : ''); ?>>Cost (Semakin kecil nilai/rasio, semakin baik)</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Bobot (%)</label>
                                                    <input type="number" step="0.01" name="weight" value="<?php echo e($crit->weight); ?>" class="form-control" required>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" name="is_active" value="1" class="form-check-input" id="active<?php echo e($crit->id); ?>" <?php echo e($crit->is_active ? 'checked' : ''); ?>>
                                                    <label class="form-check-label small" for="active<?php echo e($crit->id); ?>">Aktifkan Kriteria dalam Perhitungan SMART</label>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add New Criteria Form -->
    <div class="col-12 col-lg-4">
        <div class="card-custom p-4">
            <h6 class="fw-bold text-dark mb-3"><i class="fa-solid fa-plus-circle text-primary me-2"></i> Tambah Kriteria Baru</h6>
            <form action="<?php echo e(route('admin.criteria.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Kode Kriteria</label>
                    <input type="text" name="code" class="form-control" placeholder="Contoh: C6" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nama Kriteria</label>
                    <input type="text" name="name" class="form-control" placeholder="Nama Kriteria..." required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Tipe Kriteria</label>
                    <select name="type" class="form-select" required>
                        <option value="benefit">Benefit</option>
                        <option value="cost">Cost</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Bobot (%)</label>
                    <input type="number" step="0.01" name="weight" class="form-control" placeholder="10.00" required>
                </div>
                <button type="submit" class="btn btn-primary w-100 shadow-sm"><i class="fa-solid fa-save me-1"></i> Simpan Kriteria</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT TEMPLATE JUAL\APLIKASI ASEP\resources\views/admin/criteria/index.blade.php ENDPATH**/ ?>