<?php $__env->startSection('title', 'Lengkapi Profil Nasabah'); ?>
<?php $__env->startSection('page-title', 'Lengkapi Profil Biodata & Finansial'); ?>

<?php $__env->startSection('content'); ?>
<div class="card-custom p-4">
    <div class="mb-4 pb-3 border-bottom">
        <h5 class="fw-bold text-dark mb-1">Form Data Diri & Finansial Calon Nasabah</h5>
        <div class="text-muted small">Informasi ini digunakan langsung oleh mesin SMART untuk analisis kelayakan KPR Anda.</div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger p-3 rounded-3 mb-4">
            <ul class="mb-0 ps-3 small">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($err); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('nasabah.profile.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="row g-3">
            <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">Nama Lengkap (Sesuai KTP) <span class="text-danger">*</span></label>
                <input type="text" name="nama_lengkap" value="<?php echo e(old('nama_lengkap', $profile->nama_lengkap ?? $user->name)); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">NIK (Nomor Induk Kependudukan) <span class="text-danger">*</span></label>
                <input type="text" name="nik" value="<?php echo e(old('nik', $profile->nik ?? '')); ?>" maxlength="16" class="form-control" placeholder="16 Digit NIK" required>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Tempat Lahir <span class="text-danger">*</span></label>
                <input type="text" name="tempat_lahir" value="<?php echo e(old('tempat_lahir', $profile->tempat_lahir ?? '')); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Tanggal Lahir <span class="text-danger">*</span></label>
                <input type="date" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir', optional($profile->tanggal_lahir)->format('Y-m-d'))); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Jenis Kelamin <span class="text-danger">*</span></label>
                <select name="jenis_kelamin" class="form-select" required>
                    <option value="Laki-laki" <?php echo e(old('jenis_kelamin', $profile->jenis_kelamin ?? '') === 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                    <option value="Perempuan" <?php echo e(old('jenis_kelamin', $profile->jenis_kelamin ?? '') === 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                </select>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Nomor Handphone <span class="text-danger">*</span></label>
                <input type="text" name="no_hp" value="<?php echo e(old('no_hp', $profile->no_hp ?? $user->phone)); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Status Pernikahan <span class="text-danger">*</span></label>
                <select name="status_pernikahan" class="form-select" required>
                    <option value="Belum Menikah" <?php echo e(old('status_pernikahan', $profile->status_pernikahan ?? '') === 'Belum Menikah' ? 'selected' : ''); ?>>Belum Menikah</option>
                    <option value="Menikah" <?php echo e(old('status_pernikahan', $profile->status_pernikahan ?? '') === 'Menikah' ? 'selected' : ''); ?>>Menikah</option>
                    <option value="Cerai" <?php echo e(old('status_pernikahan', $profile->status_pernikahan ?? '') === 'Cerai' ? 'selected' : ''); ?>>Cerai</option>
                </select>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Jumlah Tanggungan <span class="text-danger">*</span></label>
                <input type="number" name="jumlah_tanggungan" value="<?php echo e(old('jumlah_tanggungan', $profile->jumlah_tanggungan ?? 0)); ?>" min="0" class="form-control" required>
            </div>

            <div class="col-12">
                <label class="form-label fw-semibold">Alamat Lengkap KTP <span class="text-danger">*</span></label>
                <textarea name="alamat" class="form-control" rows="2" required><?php echo e(old('alamat', $profile->alamat ?? '')); ?></textarea>
            </div>

            <hr class="my-4">
            <h6 class="fw-bold text-primary mb-3"><i class="fa-solid fa-briefcase me-2"></i> Informasi Pekerjaan & Finansial</h6>

            <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">Pekerjaan Saat Ini <span class="text-danger">*</span></label>
                <input type="text" name="pekerjaan" value="<?php echo e(old('pekerjaan', $profile->pekerjaan ?? '')); ?>" class="form-control" placeholder="Profesi / Jabatan" required>
            </div>

            <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">Status Pekerjaan <span class="text-danger">*</span></label>
                <select name="status_pekerjaan" class="form-select" required>
                    <?php $__currentLoopData = ['PNS/BUMN', 'Pegawai Tetap Swasta', 'Wirausaha', 'Pegawai Kontrak', 'Lainnya']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($st); ?>" <?php echo e(old('status_pekerjaan', $profile->status_pekerjaan ?? '') === $st ? 'selected' : ''); ?>><?php echo e($st); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Lama Bekerja (Dalam Bulan) <span class="text-danger">*</span></label>
                <input type="number" name="lama_bekerja_bulan" value="<?php echo e(old('lama_bekerja_bulan', $profile->lama_bekerja_bulan ?? 24)); ?>" min="0" class="form-control" placeholder="Contoh: 36 (3 thn)" required>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Penghasilan Bulanan Anda (Rp) <span class="text-danger">*</span></label>
                <input type="number" name="penghasilan_bulanan" value="<?php echo e(old('penghasilan_bulanan', $profile->penghasilan_bulanan ?? 8000000)); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Penghasilan Pasangan (Jika ada)</label>
                <input type="number" name="penghasilan_pasangan" value="<?php echo e(old('penghasilan_pasangan', $profile->penghasilan_pasangan ?? 0)); ?>" class="form-control">
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Pengeluaran Rata-rata/Bln (Rp) <span class="text-danger">*</span></label>
                <input type="number" name="pengeluaran_bulanan" value="<?php echo e(old('pengeluaran_bulanan', $profile->pengeluaran_bulanan ?? 3500000)); ?>" class="form-control" required>
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Total Cicilan Lain/Bln Saat Ini (Rp)</label>
                <input type="number" name="cicilan_lain" value="<?php echo e(old('cicilan_lain', $profile->cicilan_lain ?? 1000000)); ?>" class="form-control">
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label fw-semibold">Riwayat Kredit / SLIK <span class="text-danger">*</span></label>
                <select name="riwayat_kredit" class="form-select" required>
                    <option value="Lancar" <?php echo e(old('riwayat_kredit', $profile->riwayat_kredit ?? '') === 'Lancar' ? 'selected' : ''); ?>>Lancar (Kolektibilitas 1)</option>
                    <option value="Dalam Perhatian" <?php echo e(old('riwayat_kredit', $profile->riwayat_kredit ?? '') === 'Dalam Perhatian' ? 'selected' : ''); ?>>Dalam Perhatian (Kol 2)</option>
                    <option value="Tidak Lancar" <?php echo e(old('riwayat_kredit', $profile->riwayat_kredit ?? '') === 'Tidak Lancar' ? 'selected' : ''); ?>>Tidak Lancar (Kol 3-5)</option>
                </select>
            </div>
        </div>

        <div class="mt-4 pt-3 border-top text-end">
            <button type="submit" class="btn btn-primary px-4 py-2 rounded-3 shadow"><i class="fa-solid fa-save me-1"></i> Simpan Profil Nasabah</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT TEMPLATE JUAL\APLIKASI ASEP\resources\views/nasabah/profile.blade.php ENDPATH**/ ?>